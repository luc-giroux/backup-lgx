I18n.default_locale = 'en'

require 'redmine'
