SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Ingrid FOULON
-- Create date: 18 mai 2010
-- Description:	Trigger permettant de synchroniser
--              PhoneList avec les nouvelles tables : 
--              Employees, Contractors, Rooms, 
--              Project Offices et Various contacts
-- =============================================
USE [CiscoCallHistory];
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE TRIGGER [dbo].[SynchContactsTrigger] 
   ON  [dbo].[PhoneList]
   AFTER INSERT,DELETE,UPDATE
AS 
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @InsName varchar(100)
	DECLARE @InsLastName varchar(100)
	DECLARE @InsFirstName varchar(100)
	DECLARE @InsInternalNumberPhone varchar(100)
	DECLARE @InsExternalNumberPhone varchar(100)
	DECLARE @InsMobileNumberPhone varchar(100)
	DECLARE @InsLocationCode varchar(100)
	DECLARE @InsLocation varchar(100)
	DECLARE @InsCompagny varchar(100)
	DECLARE @InsEmail varchar(100)
	
	DECLARE @DelInternalNumberPhone varchar(100)
	
	DECLARE @flagInsert int
	SET  @flagInsert = 0
	
	DECLARE @flagDelete int
	SET  @flagDelete = 0
	
	
	SELECT @InsName =  Name,
	       @InsLastName = LastName,
	       @InsFirstName = FirstName,
	       @InsInternalNumberPhone = InternalPhoneNumber,
	       @InsExternalNumberPhone =ExternalPhoneNumber,
	       @InsMobileNumberPhone = MobilePhoneNumber,
	       @InsLocationCode  = LocationCode,
	       @InsLocation  = Location,
	       @InsCompagny = Company,
	       @InsEmail = email
  FROM inserted;
  
  SELECT @DelInternalNumberPhone = InternalPhoneNumber
  FROM deleted;
  
  
  SELECT @flagInsert = 1 
  FROM  [MOSSAPP].[dbo].[Employees],
        [MOSSAPP].[dbo].[Contractors],    
        [MOSSAPP].[dbo].[Rooms],
        [MOSSAPP].[dbo].[ProjectOffices], 
        [MOSSAPP].[dbo].[VariousContact]     
  WHERE  EmployeeInternalPhoneNumber = @InsInternalNumberPhone
  OR     ContractorPhoneNumber = @InsInternalNumberPhone
  OR     RoomPhoneNumber = @InsInternalNumberPhone
  OR     ProjectOfficePhoneNumber = @InsInternalNumberPhone
  OR     VariousContactPhoneNumber = @InsInternalNumberPhone;
  
  SELECT @flagDelete = 1 
  FROM  [MOSSAPP].[dbo].[Employees]        
  WHERE  EmployeeInternalPhoneNumber = @DelInternalNumberPhone ;
  
  SELECT @flagDelete = 2
  FROM  [MOSSAPP].[dbo].[Contractors]        
  WHERE  ContractorPhoneNumber = @DelInternalNumberPhone ;
  
  SELECT @flagDelete = 3
  FROM  [MOSSAPP].[dbo].[Rooms]        
  WHERE   RoomPhoneNumber = @DelInternalNumberPhone ;

  SELECT @flagDelete = 4
  FROM  [MOSSAPP].[dbo].[ProjectOffices]       
  WHERE  ProjectOfficePhoneNumber = @DelInternalNumberPhone ;
  
  SELECT @flagDelete = 5
  FROM  [MOSSAPP].[dbo].[VariousContact]       
  WHERE  VariousContactPhoneNumber = @DelInternalNumberPhone ; 

  -- Si cr�ation :  alors on essaie de savoir � quel type de contact la nouvelle entr�e appartient-elle?
   
  IF @flagInsert =  0  AND  @DelInternalNumberPhone is null
    	IF @InsLastName is not null AND  @InsFirstName is not null 
    	       INSERT INTO [MOSSAPP].[dbo].[Employees]([EmployeeLastname],[EmployeeFirstname],[EmployeeEmail],[EmployeeInternalPhoneNumber],[EmployeeExternalPhoneNumber],[EmployeeMobilePhoneNumber],[EmployeeLocation],[EmployeeLocationCode]) 
             VALUES(@InsLastName,@InsFirstName,@InsEmail,@InsInternalNumberPhone,@InsExternalNumberPhone,'',@InsLocation,@InsLocationCode)
             
		ELSE IF @InsName like '%C -%'  
             INSERT INTO [MOSSAPP].[dbo].[Contractors]([ContractorCompany],[ContractorLastname],[ContractorFirstname],[ContractorEmail],[ContractorPhoneNumber],[ContractorContractNumber],[ContractorLocationCode])
             VALUES(@InsCompagny ,@InsLastName,@InsFirstName,@InsEmail,@InsInternalNumberPhone,'',@InsLocationCode)
             
    	ELSE IF @InsName like '%room%' or @InsName like '%meeting%'  or @InsName like '%conference%'  or @InsName like '%salle%'
             INSERT INTO [MOSSAPP].[dbo].[Rooms]([RoomName],[RoomPhoneNumber],[RoomLocationCode])
             VALUES(@InsName,@InsInternalNumberPhone, @InsLocationCode)      
		ELSE     
             INSERT INTO [MOSSAPP].[dbo].[VariousContact]([VariousContactName],[VariousContactPhoneNumber],[VariousContactFaxNumber],[VariousContactEmail])
             VALUES(@InsName,@InsInternalNumberPhone,'',@InsEmail)    	
  
  -- Si mise � jour d'une entr�e existante :  le flagDelete d�termine dans quelle 
  -- table se trouve l'entr�e et met � jour les informations 
    	
  ELSE IF @flagDelete =  1  AND  @InsInternalNumberPhone is not null
      UPDATE [MOSSAPP].[dbo].[Employees]
      SET [EmployeeLastname] = @InsLastName,
          [EmployeeFirstname] =  @InsFirstName,
          [EmployeeEmail] = @InsEmail,
          [EmployeeInternalPhoneNumber] = @InsInternalNumberPhone,
          [EmployeeExternalPhoneNumber] = @InsExternalNumberPhone,
          [EmployeeMobilePhoneNumber] = @InsMobileNumberPhone,
          [EmployeeLocation] = @InsLocation,
          [EmployeeLocationCode] = @InsLocationCode
      WHERE EmployeeInternalPhoneNumber =  @DelInternalNumberPhone;

  ELSE IF @flagDelete =  2  AND  @InsInternalNumberPhone is not null 
      UPDATE [MOSSAPP].[dbo].[Contractors]
      SET [ContractorCompany] = @InsCompagny,  
          [ContractorLastname] = @InsLastName,  
          [ContractorFirstname] = @InsFirstName,
          [ContractorEmail] = @InsEmail,
          [ContractorPhoneNumber] = @InsInternalNumberPhone,
          [ContractorLocationCode] = @InsLocationCode
      WHERE ContractorPhoneNumber = @DelInternalNumberPhone;
   
   ELSE IF @flagDelete =  3  AND  @InsInternalNumberPhone is not null
      UPDATE [MOSSAPP].[dbo].[Rooms]
      SET [RoomName] = @InsName,      
          [RoomPhoneNumber] = @InsInternalNumberPhone,  
          [RoomLocationCode] = @InsLocationCode
      WHERE RoomPhoneNumber =  @DelInternalNumberPhone;
      
   ELSE IF @flagDelete =  4  AND  @InsInternalNumberPhone is not null
       UPDATE [MOSSAPP].[dbo].[ProjectOffices]
       SET [ProjectOfficeName] = @InsName, 
           [ProjectOfficePhoneNumber] = @InsInternalNumberPhone,           
           [ProjectOfficeEmail] = @InsEmail,
           [ProjectOfficeCountry] = @InsLocation
       WHERE ProjectOfficePhoneNumber =  @DelInternalNumberPhone           

  ELSE IF @flagDelete =  5   AND  @InsInternalNumberPhone is not null
      UPDATE [MOSSAPP].[dbo].[VariousContact]
       SET [VariousContactName] = @InsName,  
           [VariousContactPhoneNumber] = @InsInternalNumberPhone,                    
           [VariousContactEmail] = @InsEmail
      WHERE VariousContactPhoneNumber =  @DelInternalNumberPhone
  
  -- Si suppression : On regarde dans quelle table se trouve l'entr�e � supprim�e
      
  ELSE IF @flagDelete =  1  
      DELETE FROM [MOSSAPP].[dbo].[Employees]
      WHERE  EmployeeInternalPhoneNumber =  @DelInternalNumberPhone;
      
  ELSE IF @flagDelete =  2  
      DELETE FROM [MOSSAPP].[dbo].[Contractors]
      WHERE  ContractorPhoneNumber =  @DelInternalNumberPhone;
  
  ELSE IF @flagDelete =  3  
      DELETE FROM [MOSSAPP].[dbo].[Rooms]
      WHERE  RoomPhoneNumber =  @DelInternalNumberPhone;
  
  ELSE IF @flagDelete =  4  
      DELETE FROM [MOSSAPP].[dbo].[ProjectOffices]
      WHERE  ProjectOfficePhoneNumber =  @DelInternalNumberPhone;
      
  ELSE IF @flagDelete =  5  
      DELETE FROM [MOSSAPP].[dbo].[VariousContact]
      WHERE  VariousContactPhoneNumber =  @DelInternalNumberPhone;
    	
END
GO
